# Task 1 : Building the data dictionary
def get_hypertension_data(dict, TextIO):
    print("OK")

def get_low_income_data(dict, TextIO):
    print("OK")

# we need to define some helper fucntions for it 
# TextIO as the parameter means file is already open.