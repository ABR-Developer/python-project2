""" Tests to test function get_bigger_neighbourhood in a3.py """
from a3 import get_bigger_neighbourhood as gbn
from a3 import SAMPLE_DATA

def test_both_name() -> None:
    """Test that test_both_name correctly return first neighbourhood
    when both neighbourhood is not in the dictionary
    """
    result = gbn(SAMPLE_DATA, "Kipling", "Rexdale")
    assert result == "Kipling"

def test_first_name() -> None:
    """Test that test_first_name correctly return first neighbourhood
    when second neighbourhood is not in the dictionary
    """
    result = gbn(SAMPLE_DATA, "Rexdale-Kipling", "Rexdale")
    assert result == "Rexdale-Kipling"

def test_second_name() -> None:
    """Test that test_second_name correctly return second neighbourhood
    when first neighbourhood is not in the dictionary
    """
    result = gbn(SAMPLE_DATA, "Rexdale", "Elms-Old Rexdale")
    assert result == "Elms-Old Rexdale"

def test_first_bigger() -> None:
    """Test that test_first_bigger correctly returns the first neighbourhood
    when its population is strictly greater than the population of the second
    neighbourhood.
    """
    result = gbn(SAMPLE_DATA, "Rexdale-Kipling", "Elms-Old Rexdale")
    assert result == "Rexdale-Kipling"

def test_second_bigger() -> None:
    """Test that test_second_bigger correctly returns the second neighbourhood
    when its population is strictly greater than the population of the first
    neighbourhood.
    """
    result = gbn(SAMPLE_DATA,"Elms-Old Rexdale","Rexdale-Kipling")
    assert result == "Rexdale-Kipling"


if __name__ == '__main__':
    import pytest
    pytest.main(['test_a3.py'])
