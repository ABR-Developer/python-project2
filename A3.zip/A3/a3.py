"""CSC108: Fall 2022 -- Assignment 3: Hypertension and Low Income

This code is provided solely for the personal and private use of
students taking the CSC108/CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.

All of the files in this directory and all subdirectories are:
Copyright (c) 2022 Jacqueline Smith and David Liu
"""
from typing import TextIO
import statistics  # Note that this requires Python 3.10
ID = "id"
HT_KEY = "hypertension"
TOTAL = "total"
LOW_INCOME = "low_income"

# Indexes in the inner lists of hypertension data in CityData
# HT is an abbreviation of hypertension, NBH is an abbreviation of neighbourhood
HT_20_44 = 0
NBH_20_44 = 1
HT_45_64 = 2
NBH_45_64 = 3
HT_65_UP = 4
NBH_65_UP = 5

# columns in input files
ID_COL = 0
NBH_NAME_COL = 1
POP_COL = 2
LI_POP_COL = 3

SAMPLE_DATA = {
    "West Humber-Clairville": {
        "id": 1,
        "hypertension": [703, 13291, 3741, 9663, 3959, 5176],
        "total": 33230,
        "low_income": 5950,
    },
    "Mount Olive-Silverstone-Jamestown": {
        "id": 2,
        "hypertension": [789, 12906, 3578, 8815, 2927, 3902],
        "total": 32940,
        "low_income": 9690,
    },
    "Thistletown-Beaumond Heights": {
        "id": 3,
        "hypertension": [220, 3631, 1047, 2829, 1349, 1767],
        "total": 10365,
        "low_income": 2005,
    },
    "Rexdale-Kipling": {
        "id": 4,
        "hypertension": [201, 3669, 1134, 3229, 1393, 1854],
        "total": 10540,
        "low_income": 2140,
    },
    "Elms-Old Rexdale": {
        "id": 5,
        "hypertension": [176, 3353, 1040, 2842, 948, 1322],
        "total": 9460,
        "low_income": 2315,
    },
}


# This function is provided for use in Tasks 3 and 4. You should not change it.
def get_age_standardized_ht_rate(ndata: 'CityData', name: str) -> float:
    """Return the age standardized hypertension rate from the neighbourhood in
    ndata matching the given name.

    Precondition: name is in ndata

    >>> get_age_standardized_ht_rate(SAMPLE_DATA, 'Elms-Old Rexdale')
    24.44627521389894
    >>> get_age_standardized_ht_rate(SAMPLE_DATA, 'Rexdale-Kipling')
    24.72562462246556
    """
    rates = calculate_ht_rates_by_age_group(ndata, name)

    # These rates are normalized for only 20+ ages, using the census data
    # that our datasets are based on.
    canada_20_44 = 11_199_830 / 19_735_665  # Number of 20-44 / Number of 20+
    canada_45_64 = 5_365_865 / 19_735_665  # Number of 45-64 / Number of 20+
    canada_65_plus = 3_169_970 / 19_735_665  # Number of 65+ / Number of 20+

    return (rates[0] * canada_20_44
            + rates[1] * canada_45_64
            + rates[2] * canada_65_plus)
            
# Task 1 : Building the data dictionary (start) --------------------------------

def IsKeyExist(dict, key):
    # Helper function to check whether a given key already exists in a dictionary.
    if key in dict.keys():
        return True
    return False
		
def get_hypertension_data(dict, TextIO):
    lines = TextIO.readlines()
    for line in lines[1: ]:
        data = line.split(",")
        list = []
        for x in data[2 : 8]:
            if x[-2:] == '\n':
                x = x[:-2]
            list.append(int(x))
        if IsKeyExist(dict, data[1]):
            dict[data[1]][ID] = data[0]
            dict[data[1]][HT_KEY] = list
        else:
            new_dict = {}
            new_dict[ID] = int(data[0])
            new_dict[HT_KEY] = list
            dict[data[1]] = new_dict

def get_low_income_data(dict, TextIO):
    lines = TextIO.readlines()
    for line in lines[1: ]:
        data = line.split(",")
        if IsKeyExist(dict, data[1]):
            dict[data[1]][TOTAL] = int(data[2])
            dict[data[1]][LOW_INCOME] = int(data[3])
        else:
            new_dict = {}
            new_dict[ID] = int(data[0])
            new_dict[TOTAL] = int(data[2])
            new_dict[LOW_INCOME] = int(data[3])
            dict[data[1]] = new_dict

# we need to define some helper fucntions for it 
# TextIO as the parameter means file is already open.

# Task 1 : Building the data dictionary (end) --------------------------------
# Task 2 : Neighbourhood-lvel-Analysis (start) --------------------------------

def get_bigger_neighbourhood(CityData, Neighbour_1 : str, Neighbour_2: str):
    # Neighbour_1 and Neighbour_2 are name of Neighbours as they are keys in dictionary so assumed to be unique.
    if IsKeyExist(CityData , Neighbour_1):
        population_1 = CityData[Neighbour_1][TOTAL]
    else:
        population_1 = 0
    if IsKeyExist(CityData , Neighbour_2):
        population_2 = CityData[Neighbour_2][TOTAL]
    else:
        population_2 = 0
    if population_1 >= population_2:
        return Neighbour_1
    else:
        return Neighbour_2

def get_hypertension_rate(CityData, key):
    # Helper function
    nominator = CityData[key][HT_KEY][HT_20_44] + CityData[key][HT_KEY][HT_45_64] + CityData[key][HT_KEY][HT_65_UP]
    denominator = CityData[key][HT_KEY][NBH_20_44] + CityData[key][HT_KEY][NBH_45_64] + CityData[key][HT_KEY][NBH_65_UP]
    return nominator/denominator

def get_income_rate(CityData, key):
    # Helper function
    return CityData[key][LOW_INCOME] / CityData[key][TOTAL]

def get_high_hypertension_rate(CityData, threshold : float):
    # threshold : (0.0 <= x < 1.0)
    list = []
    if( threshold >= 0.0 or threshold <= 1.0):
        for x in CityData:
            neighbourhood_threshold = get_hypertension_rate(CityData, x)
            if neighbourhood_threshold >= threshold:
                new_tuple = (x , neighbourhood_threshold)
                list.append(new_tuple)
    else:
        print("Threshold x is out of range (0.0 <= x <= 1.0")
    return list

def get_ht_to_low_income_ratios(CityData): 
    dict = {}
    for x in CityData:
        dict[x] = get_hypertension_rate(CityData, x)/get_income_rate(CityData, x)
    return dict

def calculate_ht_rates_by_age_group(CityData, Key : str):
    HT_rate_20_44 = CityData[Key][HT_KEY][HT_20_44]/CityData[Key][HT_KEY][NBH_20_44]*100
    HT_rate_45_64 = CityData[Key][HT_KEY][HT_45_64]/CityData[Key][HT_KEY][NBH_45_64]*100
    HT_rate_65_UP = CityData[Key][HT_KEY][HT_65_UP]/CityData[Key][HT_KEY][NBH_65_UP]*100
    return (HT_rate_20_44,HT_rate_45_64,HT_rate_65_UP)

# Task 2 : Neighbourhood-lvel-Analysis (end) --------------------------------
# Task 3 : Finding the Correlation (start) --------------------------------

def get_stats_summary(CityData):
    age_standardized_ht_rates = []
    income_rates = []
    for x in CityData:
        age_standardized_ht_rates.append(get_age_standardized_ht_rate(CityData, x))
        income_rates.append(get_income_rate(CityData,x))
    return statistics.correlation(age_standardized_ht_rates, income_rates)

# Task 3 : Finding the Correlation (end) --------------------------------
# Task 4 : Order By Ratio (start) --------------------------------

def order_by_ht_rate(CityData):
    List = []
    for x in CityData:
        new_tuple = (get_age_standardized_ht_rate(CityData, x), x)
        List.append(new_tuple)
    List.sort()
    names = []
    for x in List:
        names.append(x[1])
    return names

# Task 4 : Order By Ratio (end)--------------------------------
# Task 5 : Required Testing (start) --------------------------------
# Task 5 : Required Testing (end) --------------------------------

if __name__ == "__main__":
    import doctest
    doctest.testmod()

    # Using the small data files
    small_data = {}

    # Add hypertension data
    ht_file = open("hypertension_data_small.csv")
    get_hypertension_data(small_data, ht_file)
    ht_file.close()

    # Add low income data
    li_file = open("low_income_small.csv")
    get_low_income_data(small_data, li_file)
    li_file.close()

    # Created dictionary should be the same as SAMPLE_DATA
    print(small_data == SAMPLE_DATA)

    # Calling get_high_hypertension_rate
    list = get_high_hypertension_rate(SAMPLE_DATA, 0.3)
    # print(list)
    
    list = get_ht_to_low_income_ratios(SAMPLE_DATA)
    # print(list)
    
    tuple = calculate_ht_rates_by_age_group(small_data, "Elms-Old Rexdale")
    # print(tuple)

    float = get_stats_summary(small_data)
    # print(float)

    list = order_by_ht_rate(small_data)
    # print(list)